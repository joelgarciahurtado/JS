/* FUNCIONS COMUNS */

function print(sortida){  // Funció per visualitzar la sortida
	var s = document.getElementById("sortida"); // Objecte #sortida
		s.innerHTML += sortida; // Afegeix una nova línia de sortida
	
	if(sortida == "") s.innerHTML = ""; // Esborra la sortida	
}


/* FUNCIONS PER FACTORIAL */

function factor(nombre){ // Funció recursiva per obtenir el factorial
   
    if (nombre < 2)
		return 1;
	else
		return nombre * factor(nombre - 1); // Es crida a si mateixa
}

function factorial(){ //Funció pel visualitzar el text del factorial

	var missatge = `
					<h1>FACTORIAL</h2>
					<form name='form'>Entra un nombre enter:
					<input name='nombre' type='number' maxlength='3' size='3' autofocus='autofocus' />
					<input type='button' onclick="print('El factorial de ' + form.nombre.value +' és ' + factor(form.nombre.value) + '<br />');" value='factorial' />
					</form><br />`

	print(""); // Esborra la sortida
    print(missatge); // Utilitza la funció print() per visualitzar la sortida

}


/* FUNCIONS PER ALEATORI */




/* FUNCIONS PER VOCALS */




/* FUNCIONS PER PRIMERS */




/* FUNCIONS PER INREVES */
